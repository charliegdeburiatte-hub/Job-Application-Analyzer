// Global type declarations for Firefox WebExtension API

declare const browser: typeof chrome;

export {};
